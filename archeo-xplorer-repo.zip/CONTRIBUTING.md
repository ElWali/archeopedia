
# Contributing

1. Fork the repo.
2. Create a feature branch.
3. Run linters & tests.
4. Open a PR with a clear description.
