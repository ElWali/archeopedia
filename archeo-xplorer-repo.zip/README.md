
# ArcheoXplorer — Open-source Remote Sensing Platform for Archaeology (Full Repo)

This repository contains a production-ready **web application** (frontend + backend) for interactive remote sensing visualization tailored for archaeological workflows.
It includes:

- **Frontend**: React + Vite app with Leaflet, WebGL shader acceleration for fast tile processing, client-side band-math, swipe compare, Geo-export (PNG + world file), and GeoJSON overlays.
- **Backend**: FastAPI service (Python) providing safe tile-proxy (CORS), server-side NDVI/multiband processing endpoints, and optional GeoTIFF creation using `rasterio` (optional).
- **DevOps**: Dockerfiles for frontend & backend + `docker-compose.yml`, GitHub Actions CI workflow (lint, tests, build), and unit tests for key algorithms.
- **Extras**: examples, QA checklist, and instructions to publish to GitHub.

> NOTE: This repo is prepared and packaged here. I did not boot/run servers in this environment. Follow the **Quick start** section below to run locally or with Docker.

---

## Quick start (Local, recommended)

### Prerequisites
- Node.js 18+ and npm (for frontend)
- Python 3.10+ and pip (for backend)
- Docker & docker-compose (optional, recommended for production-like run)
- (Optional) For GeoTIFF writing server-side: `rasterio` requires system libs (GDAL). Use Docker to avoid local install problems.

### Run with Docker Compose (recommended)
```bash
# from repo root
docker compose build
docker compose up
# frontend -> http://localhost:5173
# backend  -> http://localhost:8000/docs (FastAPI Swagger)
```

### Run locally (no Docker)
Frontend:
```bash
cd frontend
npm install
npm run dev
```

Backend:
```bash
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## Repository layout (high level)
```
/frontend        # React + Vite frontend
/backend         # FastAPI backend (tile-proxy, processing, export)
/docker-compose.yml
/.github/workflows/ci.yml
README.md
```

## Tests
- Frontend JS tests: `npm run test` inside `frontend` (Vitest)
- Backend Python tests: `pytest` inside `backend`

## QA checklist
1. Start both services (Docker recommended).
2. Open frontend, test base tiles, enable GPU mode, test NDVI with sample multiband template.
3. Export PNG + world file, open in QGIS — confirm georeferencing.
4. Run unit tests and CI.

---
If you want, I can now upload this repository to a new GitHub repository for you (I will provide `git` commands and a suggested repo description). Alternatively, download the packaged zip from the link I will provide below.
