
import aiohttp, io
from PIL import Image
import numpy as np

async def simple_tile_proxy_bytes(url: str):
    # fetch a tile and return bytes (PNG)
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as resp:
                if resp.status != 200:
                    return None
                return await resp.read()
    except Exception as e:
        print('proxy error', e)
        return None

async def ndvi_from_urls(r_url: str, nir_url: str):
    '''Fetch two tiles (R and NIR), compute NDVI and return PNG bytes.'''
    async with aiohttp.ClientSession() as session:
        async with session.get(r_url, timeout=15) as rr:
            r_bytes = await rr.read()
        async with session.get(nir_url, timeout=15) as nr:
            nir_bytes = await nr.read()
    r = Image.open(io.BytesIO(r_bytes)).convert('L').resize((256,256))
    nir = Image.open(io.BytesIO(nir_bytes)).convert('L').resize((256,256))
    r_arr = np.array(r).astype('float32')
    nir_arr = np.array(nir).astype('float32')
    denom = (nir_arr + r_arr)
    denom[denom==0] = 1e-6
    ndvi = (nir_arr - r_arr) / denom
    # map -1..1 to 0..255
    mapped = ((ndvi + 1.0) / 2.0 * 255.0).astype('uint8')
    out = Image.fromarray(mapped).convert('RGB')
    buf = io.BytesIO()
    out.save(buf, format='PNG')
    return buf.getvalue()
