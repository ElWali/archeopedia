
def build_world_file(bounds, width, height):
    south, west, north, east = bounds
    A = (east - west) / width
    E = - (north - south) / height
    B = 0.0
    D = 0.0
    C = west + A/2.0
    F = north + E/2.0
    return [A, D, B, E, C, F]

def build_world_file_text(bounds, width, height):
    arr = build_world_file(bounds, width, height)
    return '\n'.join(f"{v:.12f}" for v in arr)
