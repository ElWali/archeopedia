
from fastapi import FastAPI, HTTPException, UploadFile, File, Query
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import io, base64
from .processing import ndvi_from_urls, simple_tile_proxy_bytes
from .export import build_world_file_text

app = FastAPI(title='ArcheoXplorer Backend')

app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_methods=['*'],
    allow_headers=['*'],
)

@app.get('/health')
async def health():
    return {'status':'ok'}

@app.get('/proxy/tile')
async def proxy_tile(url: str = Query(..., description='Full tile URL to proxy (encoded)')):
    data = await simple_tile_proxy_bytes(url)
    if not data:
        raise HTTPException(status_code=502, detail='Tile fetch failed')
    return StreamingResponse(io.BytesIO(data), media_type='image/png')

@app.post('/process/ndvi')
async def process_ndvi(r_url: str = Query(None), nir_url: str = Query(None)):
    """Example endpoint that fetches R and NIR tiles and returns a small PNG (base64) with NDVI grayscale."""
    if not (r_url and nir_url):
        raise HTTPException(status_code=400, detail='r_url and nir_url required')
    png = await ndvi_from_urls(r_url, nir_url)
    return StreamingResponse(io.BytesIO(png), media_type='image/png')

@app.post('/export/worldfile')
async def export_worldfile(south: float, west: float, north: float, east: float, width: int, height: int):
    wf = build_world_file_text([south, west, north, east], width, height)
    return JSONResponse({'worldfile': wf})
