
import pytest
from app.export import build_world_file, build_world_file_text

def test_worldfile_math():
    south, west, north, east = 30.0, 10.0, 35.0, 20.0
    arr = build_world_file([south, west, north, east], 200, 100)
    # A = (east-west)/width = 10/200 = 0.05
    assert round(arr[0],6) == round(0.05,6)
    # E = -(north-south)/height = -5/100 = -0.05
    assert round(arr[3],6) == round(-0.05,6)
